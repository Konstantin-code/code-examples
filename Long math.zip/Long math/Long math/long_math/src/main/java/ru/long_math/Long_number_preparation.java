package ru.long_math;

import java.util.Scanner;
import java.util.Arrays;

public class Long_number_preparation 
{
	private Long_number ln;
	private Scanner in = new Scanner(System.in);
	
	//empty constructor
	public Long_number_preparation() 
	{
		
	}
	
	//method for return example of Long_number class (get)
	public Long_number get_Long_number()
	{
		return ln;
	}
	
	//method to delimit class parameters and fields
	public void set_Long_number(Long_number ln)
	{
		this.ln=ln;
	}
	
	//method for getting long number from console to char array
	public void Input(String message)
	{
		System.out.printf("Input %s value: ", message);
        ln.value = in.nextLine();
        ln.value_array= new char[ln.value.length()];    
	}
	
	//method for starting input and first preparing
	public void from_console(String message) 
	{
		ln = new Long_number();
		Input(message);
		To_array();
		To_Int();
	}
	
	//method for changing array of integer values to string	
	public void Array_To_string()
	{ 
		ln.value="";
		
		if (ln.int_array!=null)
		for (int i=0;i<ln.int_array.length;i++)
		{
			ln.value+=ln.int_array[i];
		}
		if (ln.Is_minus)
		{
			ln.value='-'+ln.value;
		}
	}
	
    //method for closing scanner class
	public void Close()
	{
		in.close();
	}
	
	//method for changing string to array and checking about minus
	private void To_array()
	{	
		ln.value_array=ln.value.toCharArray();
		if (ln.value_array[0]=='-') 
		{
			ln.Is_minus=true;			
		} 
	}
	
	//method for changing char array to integer array (last preparing before counting)
	private void To_Int( )
	{
		Array_flip(ln.value_array);
		char [] temp_array;
		int len_of_minus=0;
		if (ln.Is_minus)
		{	
			len_of_minus=1;		
		}
		temp_array=new char [ln.value_array.length-len_of_minus];		
		temp_array=Arrays.copyOfRange(ln.value_array,0,ln.value_array.length-len_of_minus);
	
		ln.int_array= new int [temp_array.length];
		for ( int i = 0; i<(temp_array.length); i++  )  
		{
			ln.int_array[i]=Integer.parseInt(""+temp_array[i]);
		}			
		
	}
	
	//method for flip char array
	private void Array_flip( char [] massive)
	{
	    for (int i = 0; i < massive.length / 2; i++)
	    {
	    	char  tmp = massive[i];
	        massive[i] = massive[massive.length - i - 1];
	        massive[massive.length - i - 1] = tmp;
	    }
	}
	
	//method for flip integer array
	public static void Array_flip( int [] massive) 
	{
		    for (int i = 0; i < massive.length / 2; i++)
		    {
		    	int  tmp = massive[i];
		        massive[i] = massive[massive.length - i - 1];
		        massive[massive.length - i - 1] = tmp;
		    }    
	}

	//method for cutting last element in integer array
	public static  int [] Rewrite(int [] massive)
	{
		int [] temp_array=new int [massive.length-1];	
		temp_array=Arrays.copyOfRange(massive,0,massive.length-1);
		return  temp_array;		
	}
}
