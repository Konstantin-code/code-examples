package ru.long_math;

public class Long_number
{	
	//to control presence of minus
	boolean Is_minus=false;
	
	//to containing first stage of value 
	protected String value;
	
	//to containing value to next manipulations
	protected char [] value_array;
	
	//to containing prepared for calculation value
	protected int [] int_array;
	
	//constructor for value initialization
	public Long_number()
	{
		value="";
	}	
}