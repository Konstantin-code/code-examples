package ru.long_math;

public class Counting 
{
		//constant for chosen action
		public static String Chosen_action;	

		//method for showing the report of action
		public static void Report(Long_number First,Long_number Second, Long_number Rez) 
		{			
			Output(First.value,Second.value,Chosen_action, Rez.value);			
		}
		
		//method for good output view 
		public static void Output(String first_value,String second_value,String action ,String rezult)
		{
			System.out.printf("������� ������ ����� : %s\n", first_value);
			System.out.printf("������� ������ ����� : %s\n", second_value);
			System.out.printf("������� �������� : %s\n", action);
			if (!rezult.isEmpty())
				System.out.printf("������� ��������� : %s\n", rezult);
			else 
				System.out.printf("��������� �� �������� \n");	
		}
		
		//method for multiply realization
		private static int [] Multiply(int []  A ,  int [] B ) 
		{
			int [] C = new int[A.length +B.length] ;
			Integer p;
			Integer VspRez;
			for ( int i = 0; i<A.length; i++  )  
		    {			    
		        p = 0; 
		        int j;
		        for (  j = 0;j<B.length  ; j++  ) 
		         {
		           VspRez = A[i] * B[j] + p + C[i + j ];
		           C[i + j ] = VspRez % 10; 
		           p = VspRez / 10 ;
		         }
		       C[i +j ] = p ;
		     }	
			if (C[C.length-1]==0)
				C=Long_number_preparation.Rewrite(C);
			Long_number_preparation.Array_flip(C);
			return (C); //need to flip before output
		}
		
		//input point to multiply
		public static void mlt(Long_number First,Long_number Second, Long_number Rez )
		{			
			Rez.int_array=Multiply(First.int_array,Second.int_array);
		}
		
		//method for adding realization
		private static int [] Add ( int []  A ,  int [] B) 
		{
			int maxsize=Math.max(A.length,B.length);
			int minsize=Math.min(A.length,B.length);
			int [] C = new int[maxsize+1] ;
			Integer p=0;//residue
			for (int i=0;i<minsize;i++)
			{
				p+=A[i]+B[i];
				C[i]=p%10;
				p/=10;
			}
			C[minsize]=p;
			if (maxsize != minsize)
				if (A.length>B.length)					
					for (int j=minsize;j<maxsize;j++)						
					C[j]+=A[j];
				else 
					for (int j=minsize;j<maxsize;j++)				
					C[j]+=B[j];
			if (C[C.length-1]==0)
				C=Long_number_preparation.Rewrite(C);			
			Long_number_preparation.Array_flip(C);
			return (C);
			
		}
		
		//input point to add
		public static void add(Long_number First,Long_number Second, Long_number Rez )
		{			
			Rez.int_array=Add(First.int_array,Second.int_array);
		}
		
		//method for subtracting realization
		private static int [] Subtract (int [] A ,  int [] B)
		{
			int [] C = new int[A.length] ;
			int [] sub_array= new int [B.length];
			for(int i=0;i<sub_array.length;i++)
			{				
				sub_array[i]=9-B[i];				
			}
			sub_array[0]+=1;
			C=Add(A,sub_array);
			Long_number_preparation.Array_flip(C);	
			C[B.length]-=1;				
			while (C[C.length-1]==0) 
			{
				C=Long_number_preparation.Rewrite(C);	
			}
			Long_number_preparation.Array_flip(C);
			return (C);	
		}
	
		//input point to subtract
		public static void sub(Long_number First,Long_number Second, Long_number Rez )
		{
			Rez.int_array=Subtract(First.int_array,Second.int_array);
		}
		
		//method for compare to numbers (if abs of first number lesser than second, return true)
		public static boolean size_check(Long_number First,Long_number Second )
		{
			if(First.int_array.length<Second.int_array.length)
			       return true;
			
			if(First.int_array.length>Second.int_array.length)
			       return false;
						
				int i=0;
			while (i<First.int_array.length)
			{
				if(First.int_array[i]<Second.int_array[i])return true;
			    if(First.int_array[i]>Second.int_array[i])return false;
			}
			return false;
		}
	

}
