package ru.long_math;
import java.util.Scanner;
public class Head
{
	//method for checking the features of adding and change for optimal action
	public static void Add_Check(Long_number fst, Long_number snd, Long_number rez)
	{
		
			if(!fst.Is_minus && !snd.Is_minus)
			{
				Counting.add(fst,snd,rez);
				rez.Is_minus=false;
			}
			if(fst.Is_minus && !snd.Is_minus)
			{
				if (Counting.size_check(fst,snd))
				{
					Counting.sub(snd,fst,rez);
					rez.Is_minus= false;
				}
				else
				{
					Counting.sub(fst,snd,rez);
					rez.Is_minus= true;
				}
			}
			if(fst.Is_minus && snd.Is_minus)
			{
				Counting.add(fst,snd,rez);
				rez.Is_minus= true;
			}
			if(!fst.Is_minus && snd.Is_minus) 
			{
				if (!Counting.size_check(fst,snd))
				{
					Counting.sub(fst,snd,rez);
					rez.Is_minus= false;
				}
				else
				{
					Counting.sub(snd,fst,rez);
					rez.Is_minus= true;
				}
			}
			
	}
	
	//method for checking the features of subtraction and change for optimal action
	public static void Sub_Check(Long_number fst, Long_number snd, Long_number rez)
	{
		if(!fst.Is_minus && !snd.Is_minus)
		{
			if (!Counting.size_check(fst,snd))
			{
				Counting.sub(fst,snd,rez);
				rez.Is_minus= false;
			}
			else
			{
				Counting.sub(snd,fst,rez);
				rez.Is_minus= true;
			}
			
		}
		if(fst.Is_minus && !snd.Is_minus)
		{
			Counting.add(fst,snd,rez);
			rez.Is_minus= true;
		}
		if(fst.Is_minus && snd.Is_minus)
		{
			if (Counting.size_check(fst,snd))
			{
				Counting.sub(snd,fst,rez);
				rez.Is_minus= false;
			}
			else
			{
				Counting.sub(fst,snd,rez);
				rez.Is_minus= true;
			}
		}
		if(!fst.Is_minus && snd.Is_minus) 
		{
			Counting.add(fst,snd,rez);
			rez.Is_minus= false;
		}
			
	}
	
	//method for checking the features of multiplication and change for optimal action
	public static void Mlt_Check(Long_number fst, Long_number snd, Long_number rez)
	{
		if (((fst.int_array[0] == 0)&&(fst.int_array.length==1))||((snd.int_array[0] == 0)&&(snd.int_array.length==1)))
		{
			rez.int_array=new int[1];
			rez.int_array[0]=0;
			rez.Is_minus= false;
		}
		else
		{
			Counting.mlt(fst,snd,rez);		
			rez.Is_minus=(fst.Is_minus != snd.Is_minus);
		}
	}
	
	//input point to program
	public static void main(String[]args)
	{	
		//calling methods for input and primary processing of a value
		Integer choose;
		Long_number_preparation lnp = new Long_number_preparation ();		
	
		lnp.from_console("first");
		Long_number First_value = lnp.get_Long_number();
		lnp.from_console("second");
		Long_number Second_value = lnp.get_Long_number();		
		Long_number  Rezult=new Long_number();
		
		//asking user about needed action 
		System.out.print("�������� ��������: 1-�������� ; 2-��������� ; 3-��������� ");
		Scanner scan = new Scanner(System.in);
		choose=scan.nextInt();
		scan.close();		
		lnp.Close();
		
		//realization of choose action and calling method for checking
		switch(choose)
		{
			case 1:
			{			
				Counting.Chosen_action="��������";
				Add_Check(First_value,Second_value,Rezult);
				//Counting.add(First_value,Second_value,Rezult);
				lnp.set_Long_number(Rezult);
				lnp.Array_To_string();
				Rezult=lnp.get_Long_number();
				Counting.Report(First_value,Second_value,Rezult);
				break;
			}
			case 2:
			{
				Counting.Chosen_action="���������";
				Sub_Check(First_value,Second_value,Rezult);
				//Counting.sub(First_value,Second_value,Rezult);
				lnp.set_Long_number(Rezult);
				lnp.Array_To_string();
				Rezult=lnp.get_Long_number();
				Counting.Report(First_value,Second_value,Rezult);
				break;
			}
			case 3:
			{
				Counting.Chosen_action="���������";
				Mlt_Check(First_value,Second_value,Rezult);
				//Counting.mlt(First_value,Second_value,Rezult);
				lnp.set_Long_number(Rezult);
				lnp.Array_To_string();
				Rezult=lnp.get_Long_number();
				Counting.Report(First_value,Second_value,Rezult);	
				break; 	  
			}
			default: System.out.print("������������ ����");				
		}		
	}		
}